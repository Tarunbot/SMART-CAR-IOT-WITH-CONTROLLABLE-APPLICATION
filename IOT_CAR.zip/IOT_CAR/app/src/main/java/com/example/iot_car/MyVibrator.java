package com.example.iot_car;

import android.os.Vibrator;
import android.content.Context;

public class MyVibrator {
    // Vibrate for a specific duration
    public static void vibrate(Context context, long milliseconds) {
        Vibrator vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
        if (vibrator != null) {
            vibrator.vibrate(milliseconds);
        }
    }

    // Vibrate with a pattern (e.g., short vibration, pause, long vibration)
    public static void vibratePattern(Context context, long[] pattern, int repeat) {
        Vibrator vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
        if (vibrator != null) {
            vibrator.vibrate(pattern, repeat);
        }
    }
}
