package com.example.iot_car;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.UUID;

import android.os.ParcelUuid;

import javax.security.auth.login.LoginException;

public class MainActivity extends AppCompatActivity{
    private static final int REQUEST_ENABLE_BT = 1;
    private static final int REQUEST_LOCATION_PERMISSION = 2;
    Button up,down,left,right,stop,automatic,manual;
    boolean automaticc=false;
    int turnlocal=0;
    int clicked=0;
    int tunnlocal=0;
    TextView Odistance,Wrotation;
    boolean vibrate=false;

    boolean ultrasonic=false;
    private BluetoothAdapter bluetoothAdapter;
    static int send=0;
    private BluetoothDevice connectedDevice;
    private BluetoothSocket bluetoothSocket;
    private OutputStream outputStream;

    private Button connectButton,reset,ultraoN;
    private Button infoBtn;

    String rot="0.0";
    String diss="0.0";
    static File csvdata;
    private String DEVICE_ADDRESS = "B8:D6:1A:B2:F9:B2"; // Replace with your device's Bluetooth MAC address
    private UUID MY_UUID = null; // Replace with your UUID

    private static final String TAG = "BluetoothExample";
    FileWriter fileWriter;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.e(TAG, "UUID: ");


        connectButton = findViewById(R.id.connectButton);
        infoBtn = findViewById(R.id.INFO);
        File downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);

        // Create a File object with the specified directory and file name
        csvdata = new File(downloadsDir, "Tracks.txt");

        try {
            csvdata.createNewFile();
            fileWriter=new FileWriter(csvdata,true);



        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        Odistance=findViewById(R.id.Odistance);
        Wrotation=findViewById(R.id.Wrotations);
        Odistance.setBackgroundColor(Color.parseColor("#373535"));
        Wrotation.setBackgroundColor(Color.parseColor("#373535"));
        Odistance.setTextColor(Color.parseColor("#FFFFFFFF"));
        Wrotation.setTextColor(Color.parseColor("#FFFFFFFF"));
        reset=findViewById(R.id.reset);
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rot=""+0.0;
                diss=""+0.0;
                csvdata = new File(downloadsDir, "Tracks.txt");
                try {
                    csvdata.createNewFile();
                    fileWriter=new FileWriter(csvdata,false);
                    fileWriter.flush();
                    fileWriter=new FileWriter(csvdata,true);
                    turnlocal=0;
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }


            }
        });

        ultraoN=findViewById(R.id.ultraon);
        ultraoN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            }
        });
        Thread vib=new Thread(new Runnable() {
            @Override
            public void run() {
                while(true){

                    if(vibrate==true){
                        MyVibrator.vibrate(getApplicationContext(),100);
                    }

                }
            }
        });
        vib.start();

        infoBtn.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("MissingPermission")
            @Override
            public void onClick(View view) {
                if(bluetoothSocket==null)checkBluetoothPermissionAndConnect();
                sendBluetoothData("info");
                byte[] bs = new byte[2048];

                try {
                    bluetoothSocket.getInputStream().read(bs);
                    String result = new String(bs, "UTF-8");

                    String[] str = result.split(",");
                    if (str.length > 2) {
                        rot=str[1];
                        diss=str[0];
//                        Wrotation.setText("WRotation : " + str[1]);
//                        Odistance.setText("ODistance : " + str[0]);
                    }
                    Log.e("data",result);
                    fileWriter.write(result);
                    fileWriter.flush();
                    Log.e("error", result);
                } catch (IOException e) {
                    Log.e("error","failer here");
                    throw new RuntimeException(e);
                }



                }




        });

        up=findViewById(R.id.Up);
        down=findViewById(R.id.down);
        left =findViewById(R.id.left);
        right =findViewById(R.id.right);
        stop =findViewById(R.id.automatic);
        automatic =findViewById(R.id.automatic);
        manual =findViewById(R.id.manual);
        ConstraintLayout root=findViewById(R.id.root);
        root.setBackgroundColor(Color.parseColor("#868E92"));

        up.setBackgroundColor(Color.parseColor("#25C557"));
        connectButton.setBackgroundColor(Color.parseColor("#FCF7F8"));
        left.setBackgroundColor(Color.parseColor("#23A6EC"));
        right.setBackgroundColor(Color.parseColor("#23A6EC"));

        down.setBackgroundColor(Color.parseColor("#E80E28"));
        automatic.setBackgroundColor(Color.parseColor("#34D4D1"));
        manual.setBackgroundColor(Color.parseColor("#7862BC"));

                bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        ParcelUuid[] uuids = bluetoothAdapter.getRemoteDevice(DEVICE_ADDRESS).getUuids();

        if(uuids!=null){

            MY_UUID=uuids[0].getUuid();
            Log.e("error","data"+ MY_UUID);
        }else{
            Log.e("wee","error ho gya be");
        }
        if (bluetoothAdapter == null) {
            Toast.makeText(this, "Bluetooth is not supported on this device", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        connectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkBluetoothPermissionAndConnect();

            }
        });


       up.setOnTouchListener(new View.OnTouchListener() {
           @Override
           public boolean onTouch(View view, MotionEvent motionEvent) {
               int trig=0;
               switch (motionEvent.getAction()){
                   case MotionEvent.ACTION_DOWN: Log.e(""," Pressed");sendBluetoothData("s");vibrate=true;up.setBackgroundColor(Color.parseColor("#387A4D"));break;
                   case MotionEvent.ACTION_UP: Log.e("","not Pressed");sendBluetoothData("br");vibrate=false;up.setBackgroundColor(Color.parseColor("#25C557"));break;
               }
               return false;
           }
       });
        down.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {

                switch (motionEvent.getAction()){
                    case MotionEvent.ACTION_DOWN: Log.e(""," Pressed");sendBluetoothData("back");vibrate=true;down.setBackgroundColor(Color.parseColor("#A94551"));break;
                    case MotionEvent.ACTION_UP: Log.e("","not Pressed");sendBluetoothData("br");vibrate=false;down.setBackgroundColor(Color.parseColor("#E80E28"));break;
                }
                return false;
            }
        });

        left.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {

                switch (motionEvent.getAction()){
                    case MotionEvent.ACTION_DOWN: Log.e(""," Pressed");sendBluetoothData("l");vibrate=true;left.setBackgroundColor(Color.parseColor("#273B45"));break;
                    case MotionEvent.ACTION_UP: Log.e("","not Pressed");sendBluetoothData("br");vibrate=false;left.setBackgroundColor(Color.parseColor("#23A6EC"));break;

                }

                return false;
            }
        });

        right.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        right.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {

                switch (motionEvent.getAction()){
                    case MotionEvent.ACTION_DOWN: Log.e(""," Pressed");vibrate=true;sendBluetoothData("r");right.setBackgroundColor(Color.parseColor("#273B45"));break;
                    case MotionEvent.ACTION_UP: Log.e("","not Pressed");vibrate=false;sendBluetoothData("br");


                    right.setBackgroundColor(Color.parseColor("#23A6EC"));break;

                }
                return false;
            }
        });



        automatic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendBluetoothData("automatic");
                automaticc=true;


            }
        });
        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                while (true) {

                    Wrotation.setText("WRotation : " + rot);
                    Odistance.setText("ODistance : " + diss);
                    byte[] buffer = new byte[1024]; // Adjust the buffer size as needed
                    int bytesRead;
                    String[] vector=new String[6];

                    while (automaticc) {

                        try {
                            Thread.sleep(2000);
                            bytesRead=bluetoothSocket.getInputStream().read(buffer);
                            if(bytesRead!=-1) {
                                String result = new String(buffer, 0, bytesRead, "UTF-8");
                                Log.e("error", result);
                                String[] str = result.split(",");
                                if (str.length > 3) {

                                    Log.e("data", result + " " + result.length());

                                        try {
                                            double rot = Double.parseDouble(str[1])*15.0;
                                            double du = Double.parseDouble(str[0]);


                                            Wrotation.setText("WRotation : " + rot);
                                            Odistance.setText("ODistance : " + du);
                                            Log.e("here","entered");
                                            if(turnlocal%3==0){
                                                vector[4]=""+rot;
                                                vector[5]=str[2];
                                                fileWriter.write(Arrays.toString(vector));
                                                fileWriter.flush();
                                            }else{
                                                if(turnlocal%3==0) {
                                                    vector[0] = "" + rot;
                                                    vector[1] = str[2];
                                                }else{
                                                    vector[2]=""+rot;
                                                    vector[3]=str[2];
                                                }
                                            }
                                            turnlocal++;

                                        } catch (Exception e) {

                                        }



                                }
                            }
                            Thread.sleep(1000);


                        } catch (IOException e) {
                            Log.e("error", "failer here");
                            throw new RuntimeException(e);
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                    }

                    if (clicked == 1) {
                        Log.e("sended", "sended done");

                        clicked=0;
                    }
                }
            }
        });
        manual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendBluetoothData("manual");
                automaticc=false;
            }
        });




    }

    private void checkBluetoothPermissionAndConnect() {
        if (!bluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
        } else if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.BLUETOOTH_CONNECT},
                    REQUEST_LOCATION_PERMISSION);
        } else {
            connectBluetoothDevice();
        }
    }

    private void connectBluetoothDevice() {
        BluetoothDevice device = bluetoothAdapter.getRemoteDevice(DEVICE_ADDRESS);

        try {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {

            }
            bluetoothSocket = device.createRfcommSocketToServiceRecord(MY_UUID);
            bluetoothSocket.connect();
            outputStream = bluetoothSocket.getOutputStream();
            connectedDevice = device;
            Toast.makeText(this, "Connected to " + device.getName(), Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            Log.e(TAG, "Error connecting to device", e);
            Toast.makeText(this, "Connection failed", Toast.LENGTH_SHORT).show();
        }
    }

    private void sendBluetoothData(String str) {
        if (outputStream != null) {
            try {

                outputStream.write(str.getBytes());
                Log.e("sent","data sent"+str);
            } catch (IOException e) {
                Log.e(TAG, "Error sending data", e);


            }
        } else {

        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_ENABLE_BT) {
            if (resultCode == Activity.RESULT_CANCELED) {
                Toast.makeText(this, "Bluetooth activation denied", Toast.LENGTH_SHORT).show();
            } else {
                checkBluetoothPermissionAndConnect();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_LOCATION_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                connectBluetoothDevice();
            } else {
                Toast.makeText(this, "Bluetooth Connect permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (bluetoothSocket != null) {
            try {
                bluetoothSocket.close();
            } catch (IOException e) {
                Log.e(TAG, "Error closing Bluetooth socket", e);
            }
        }
    }



}



